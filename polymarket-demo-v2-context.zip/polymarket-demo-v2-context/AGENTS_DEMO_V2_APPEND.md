# DEMO V2 AGENTS.md addition

Append the following section to the repository-level AGENTS.md without removing existing LIVE safety rules:

## DEMO V2 tasks

When a task explicitly concerns DEMO V2, the LIVE safety rules above still apply because the repository contains real-trading production code. Also read, in order:

1. docs/demo-v2/PROJECT_CONTEXT.md
2. docs/demo-v2/SOURCE_OF_TRUTH.md
3. docs/demo-v2/DECISIONS.md
4. docs/demo-v2/EXISTING_SYSTEM_REFERENCE.md
5. docs/demo-v2/REUSE_GUIDE.md
6. docs/demo-v2/API_CONTRACT.md
7. docs/demo-v2/IMPLEMENTATION_ROADMAP.md
8. docs/demo-v2/VALIDATION_MATRIX.md

Additional rules:
- DEMO V2 is simulated trading only and must remain isolated from LIVE.
- Do not use real-trading adapters, private keys, signing, authenticated order submission, real cancellation, redemption, emergency-close or LIVE financial state in DEMO V2.
- Reuse existing tested public-market-data, order-book, resolution, accounting and recovery primitives where safe instead of rewriting them.
- Legacy DEMO behavior is reference only when it conflicts with SOURCE_OF_TRUTH.md.
- Frontend/UI implementation is out of scope unless a later explicit instruction changes scope.
- Do not create/modify DEMO pages, React components, CSS, UI mockups or visual design in backend DEMO V2 work.
- Build and document clean backend APIs/data contracts for the separate UI workflow.
- Any DEMO deployment/service/database/config must be separate from LIVE.
