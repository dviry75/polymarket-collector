# DEMO V2 Documentation

Canonical context package for Polymarket DEMO V2.

Read order: PROJECT_CONTEXT.md, SOURCE_OF_TRUTH.md, DECISIONS.md, EXISTING_SYSTEM_REFERENCE.md, REUSE_GUIDE.md, API_CONTRACT.md, IMPLEMENTATION_ROADMAP.md, VALIDATION_MATRIX.md.

Repository-level AGENTS.md and SYSTEM_CONTEXT.md remain mandatory because this repository also contains the real LIVE trading system.

Priority when docs disagree: explicit current user instruction > SOURCE_OF_TRUTH.md > DECISIONS.md > current implementation/tests > historical plans.

Frontend/UI implementation is out of scope for Codex/backend work.
