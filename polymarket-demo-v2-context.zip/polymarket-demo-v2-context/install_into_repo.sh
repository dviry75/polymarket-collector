#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
mkdir -p "$ROOT/docs/demo-v2"
cp -f "$(dirname "$0")/docs/demo-v2/"*.md "$ROOT/docs/demo-v2/"
cat "$(dirname "$0")/AGENTS_DEMO_V2_APPEND.md" >> "$ROOT/AGENTS.md"
echo "Installed DEMO V2 docs. Review with: git status --short && git diff -- AGENTS.md docs/demo-v2"
